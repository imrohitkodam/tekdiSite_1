<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_stories_outcomes
 *
 * @copyright   Copyright (C) 2025 Your Company. All rights reserved.
 * @license     GNU General Public License version 2 or later
 */

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;

// Ensure heading tag is valid
$allowedTags = ['h2', 'h3', 'h4', 'h5', 'h6'];
if (!in_array($headingTag, $allowedTags)) {
    $headingTag = 'h3';
}
?>

<div class="stories-outcomes <?php echo $moduleClass; ?>">
    <?php if (!empty($items)) : ?>
        <?php if (!empty($groupTitle)) : ?>
            <div class="stories-outcomes__group-title">
                <h2><?php echo htmlspecialchars($groupTitle, ENT_QUOTES, 'UTF-8'); ?></h2>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($fieldLabel)) : ?>
            <div class="stories-outcomes__field-label">
                <h3><?php echo htmlspecialchars($fieldLabel, ENT_QUOTES, 'UTF-8'); ?></h3>
            </div>
        <?php endif; ?>
        
        <div class="stories-outcomes__items">
            <?php foreach ($items as $item) : ?>
                <div class="stories-outcomes__item">
                    <?php if (!empty($item['title'])) : ?>
                        <?php if (!empty($item['title_label'])) : ?>
                            <label class="stories-outcomes__field-label-item"><?php echo htmlspecialchars($item['title_label'], ENT_QUOTES, 'UTF-8'); ?></label>
                        <?php endif; ?>
                        <<?php echo $headingTag; ?> class="stories-outcomes__title">
                            <?php echo htmlspecialchars($item['title'], ENT_QUOTES, 'UTF-8'); ?>
                        </<?php echo $headingTag; ?>>
                    <?php endif; ?>
                    
                    <?php if (!empty($item['description'])) : ?>
                        <?php if (!empty($item['description_label'])) : ?>
                            <label class="stories-outcomes__field-label-item"><?php echo htmlspecialchars($item['description_label'], ENT_QUOTES, 'UTF-8'); ?></label>
                        <?php endif; ?>
                        <div class="stories-outcomes__description">
                            <?php echo nl2br(htmlspecialchars($item['description'], ENT_QUOTES, 'UTF-8')); ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else : ?>
        <p class="stories-outcomes__empty">No stories outcomes available.</p>
    <?php endif; ?>
</div>
